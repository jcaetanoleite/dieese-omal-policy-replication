#                            POF 2017-2018

#  PROGRAMA PARA GERA��O DAS VARI�VEIS PARA O INDICADOR DE POBREZA
# MULTIDIMENSIONAL COM COMPONENTE RELATIVO

# N�VEL GEOGR�FICO - BRASIL

# � preciso executar antes o arquivo "Leitura dos Microdados - R.R"
# que se encontra no arquivo compactado "Programas_de_Leitura.zip"
  # Este passo � necess�rio para gerar os arquivos com a extens�o .rds
# EM FORMATO ESPEC�FICO DO r QUE correspondentes aos arquivos com 
# extens�o .txt dos microdados da POF

# "....." indica a pasta/diret�rio de trabalho no HD local separados por "/"
# onde se encontram os arquivos .txt descompactados do arquivo Dados_aaaammdd.zip
# Exemplo: setwd("c:/POF2018/Dados_aaaammdd/")

setwd(".....") # Caminho onde se encontram as bases de dados


# Leitura da base de dados para c�culo dos indicadores de qualidade de vida

morador_quali_vida <- readRDS("MORADOR_QUALI_VIDA.rds")


# Calculo do Ci (CONTAGEM PONDERADA) e Vi (FUN��O PERDA)

# c�lculo do CI (CONTAGEM PONDERADA)
  
morador_quali_vida <- transform( morador_quali_vida,
                                 CI = V201 * 1/72 + #Peso final do vetor 201
                                   V202 * 1/72 + #Peso final do vetor 202
                                   V217 * 1/144 + #Peso final do vetor 217
                                   V204 * 1/144 + #Peso final do vetor 204
                                   V205 * 1/72 + #Peso final do vetor 205
                                   V206 * 1/144 + #Peso final do vetor 206
                                   V207 * 1/144 + #Peso final do vetor 207
                                   V210 * 1/144 + #Peso final do vetor 210
                                   V211 * 1/144 + #Peso final do vetor 211
                                   V208 * 1/72 + #Peso final do vetor 208
                                   V209 * 1/72 + #Peso final do vetor 209
                                   V212 * 1/72 + #Peso final do vetor 212
                                   V214 * 1/72 + #Peso final do vetor 214
                                   V215 * 1/72 + #Peso final do vetor 215
                                   V216 * 1/72 + #Peso final do vetor 216
                                   
                                   V301 * 1/48 + #Peso final do vetor 301
                                   V302 * 1/48 + #Peso final do vetor 302
                                   V303 * 1/48 + #Peso final do vetor 303
                                   V304 * 1/48 + #Peso final do vetor 304
                                   V305 * 1/48 + #Peso final do vetor 305
                                   V306 * 1/48 + #Peso final do vetor 306
                                   V307 * 1/48 + #Peso final do vetor 307
                                   V308 * 1/48 + #Peso final do vetor 308
                                   
                                   V501 * 1/30 + #Peso final do vetor 501
                                   V502 * 1/30 + #Peso final do vetor 502
                                   V503 * 1/30 + #Peso final do vetor 503
                                   V504 * 1/60 + #Peso final do vetor 504
                                   V505 * 1/60 + #Peso final do vetor 505
                                   V506 * 1/30 + #Peso final do vetor 506
                                   
                                   V401 * 1/30 + #Peso final do vetor 401
                                   V402 * 1/30 + #Peso final do vetor 402
                                   V403 * 1/30 + #Peso final do vetor 403
                                   
                                   V701 * 1/90 + #Peso final do vetor 701
                                   V702 * 1/90 + #Peso final do vetor 702
                                   V703 * 1/90 + #Peso final do vetor 703
                                   V704 * 1/30 + #Peso final do vetor 704
                                   
                                   V601 * 1/24 + #Peso final do vetor 601
                                   V602 * 1/120 + #Peso final do vetor 602
                                   V603 * 1/120 + #Peso final do vetor 603
                                   V604 * 1/120 + #Peso final do vetor 604
                                   V605 * 1/240 + #Peso final do vetor 605
                                   V611 * 1/240 + #Peso final do vetor 611
                                   V606 * 1/120 + #Peso final do vetor 606
                                   V607 * 1/48 + #Peso final do vetor 607
                                   V608 * 1/48 + #Peso final do vetor 608
                                   V609 * 1/48 + #Peso final do vetor 609
                                   V610 * 1/48 + #Peso final do vetor 610
                                   
                                   V801 * 1/24 + #Peso final do vetor 801
                                   V802 * 1/24 + #Peso final do vetor 802
                                   
                                   V901 * 1/24 + #Peso final do vetor 901
                                   V902 * 1/24 #Peso final do vetor 902
                                   )


# C�lculo do VI (FUN��O PERDA)

morador_quali_vida <- transform( morador_quali_vida,
                                 VI = (exp(CI) - 1)/(exp(1) - 1)
                                 )


# CALCULO DO INDICADOR FUZZY (�ndice de pobreza multidimensional com componente relativo)

# calculando o peso total acumulado de todos os moradores

(Peso_total_exp <- sum(morador_quali_vida$PESO_FINAL))
# peso_total_exp corresponde ao acumulado dos pesos expandidos de todos os moradores


# ordena o arquivo de moradores do maior Vi para o menor Vi

INDICADOR_CI_VI <- morador_quali_vida[,
                                      c("COD_UPA",
                                        "NUM_DOM",
                                        "NUM_UC",
                                        "COD_INFORMANTE",
                                        "PESO_FINAL",
                                        "VI"
                                        )
                                      ]
INDICADOR_CI_VI <- INDICADOR_CI_VI[order(INDICADOR_CI_VI$VI, 
                                         decreasing=T), 
                                   ] # No caso, ordena de acordo VI em ordem decrescente


# Calcula o peso acumulado para todos os moradores
# com base no arquivo do maior Vi para o menor Vi

soma=0
INDICADOR_CI_VI$PESO_ACUMULADO <- 0
for(i in 1:dim(INDICADOR_CI_VI)[1]){
  INDICADOR_CI_VI$PESO_ACUMULADO[i] = INDICADOR_CI_VI$PESO_FINAL[i] + soma
  soma = soma + INDICADOR_CI_VI$PESO_FINAL[i]
}


# calculando os MJs
# quanto maior o Vi, maior o MJ

INDICADOR_CI_VI <- transform(INDICADOR_CI_VI,
                             MJ = log(1/(PESO_ACUMULADO/Peso_total_exp))
                             )


# Assumindo para todos os moradores com o mesmo Vi

# Replicando o menor MJ para todos os moradores que apresentaram o mesmo Vi

INDICADOR_CI_VI_uc <- aggregate(MJ ~ COD_UPA + NUM_DOM + NUM_UC,
                                INDICADOR_CI_VI,
                                min
                                )
names(INDICADOR_CI_VI_uc) <- c("COD_UPA",
                               "NUM_DOM",
                               "NUM_UC",
                               "MM"
                               )
INDICADOR_CI_VI <- merge(INDICADOR_CI_VI,
                         INDICADOR_CI_VI_uc
                         )


# criando uma variavel MJ2 para este novo valor
  
INDICADOR_CI_VI$MJ2 <- 0
vs <- unique(INDICADOR_CI_VI$VI)
for(v in vs){
  INDICADOR_CI_VI[INDICADOR_CI_VI$VI==v,]$MJ2 = min(INDICADOR_CI_VI[INDICADOR_CI_VI$VI==v,]$MJ)
}


# Determinando os valores minimo e maximo para a variavel MJ2

resumo2 <- summary(INDICADOR_CI_VI$MJ2)


# Calculando MIJ para determinar parte da f�rmula da medida de FUZZY

INDICADOR_CI_VI <- transform(INDICADOR_CI_VI,
                             MIJ = (MJ2-resumo2[1])/(resumo2[6]-resumo2[1])
                             )


# calculando a medida de FUZZY: Fuzzy = raiz quadrada de (mij*VI)

INDICADOR_CI_VI <- transform(INDICADOR_CI_VI,
                             Fuzzy = sqrt(MIJ*VI)
                             )

# Observa��o: as vari�veis foram criadas dentro da tabela (data frame) INDICADOR_CI_VI