#                            POF 2017-2018

#  PROGRAMA PARA GERA��O DAS ESTIMATIVAS DA tabela 2 da publica��o: 
#  Pesquisa de Or�amentos Familiares 2017-2018: An�lise da seguran�a alimentar no Brasil
#  referentes aos dados da POF 2017-2018

# [1] Leitura do arquivo com as popula��es dos p�s estratos. 
#     Estas popula��es s�o necess�rias para implementar o ajuste de p�s-estratifica��o
#     dos pesos originais que resultam nos pesos finais.

# "....." indica a pasta/diret�rio de trabalho no HD local separados por "/"
# onde se encontram os arquivos .xls ou .xlsx de documenta��o dos microdados
# Exemplo: setwd("c:/POF2018/Documentacao_aaaammdd")

setwd(".....") # ..... � o caminho para a pasta "/Documentacao__aaaammdd/"

pos_estrato <-
  readxl::read_excel(
    "Pos_estratos_totais.xlsx",skip=5) # [1]


# Leitura das bases de trabalho

# � preciso executar antes o arquivo "Leitura dos Microdados - R.R"
# que se encontra no arquivo compactado "Programas_de_Leitura.zip"
# Este passo � necess�rio para gerar os arquivos com a extens�o .rds
# correspondentes aos arquivos com extens�o .txt dos microdados da POF

# "....." indica a pasta/diret�rio de trabalho no HD local separados por "/"
# onde se encontram os arquivos .txt descompactados do arquivo Dados_aaaammdd.zip
# Exemplo: setwd("c:/POF2018/Dados_aaaammdd/")

setwd(".....") # ..... � o caminho para a pasta onde se encontram os arquivos .txt descompactados do arquivo Dados_aaaammdd.zip

POF6 <- readRDS("CONDICOES_VIDA.rds")

DOMICILIO <- readRDS("DOMICILIO.rds")

# Iniciando a base de trabalho
POF6_novo <- merge(POF6,
                   pos_estrato,
                   by.x = "COD_UPA" ,
                   by.y = "COD_UPA(UF+SEQ+DV)") 

rm(pos_estrato,POF6)

# Limpando as vari�veis que duplicaram no merge
POF6_novo <- transform(POF6_novo,
                       ESTRATO_POF.y = NULL,
                       ESTRATO_POF = ESTRATO_POF.x,
                       ESTRATO_POF.x = NULL,
                       uf = NULL)

### Base com vari�veis de domic�lios
# selecionando apenas a vari�vel derivada da EBIA
domicilio <- DOMICILIO[,c("COD_UPA",
                          "NUM_DOM",
                          "V6199")] # EBIA

# Atualiza��o da base de trabalho com a base por domic�lio anterior:
POF6_novo <- merge( POF6_novo, domicilio)

rm(DOMICILIO,domicilio)

# Estimando o total de UCs por p�s estrato projetada para a data da POF
tot_uc <- aggregate(PESO_FINAL~pos_estrato,
                    sum,
                    data=POF6_novo)

colnames(tot_uc) <- c("pos_estrato",
                      "Freq")

# Carregando pacote survey():
library(survey)			# load survey package (analyzes complex design surveys)

# Especifica��o que faz o R produzir erros-padr�es convervadores no lugar de buggar
options( survey.lonely.psu = "adjust" )
# Equivalente � op��o MISSUNIT no SUDAAN

sample.pof <- svydesign(id = ~COD_UPA ,
                        strata = ~ESTRATO_POF ,
                        data = POF6_novo ,
                        weights = ~PESO ,
                        nest = TRUE	)

desenho.pof <- postStratify(design = sample.pof ,
                            ~ pos_estrato ,
                            tot_uc)

rm(sample.pof,
   POF6_novo)

# Cria��o de vari�vel auxiliar para as estimativas de preval�ncias
desenho.pof <- transform(desenho.pof,
                         one = 1)

# Especifica��o das vari�veis da EBIA
desenho.pof <- update( desenho.pof ,
                       ebia_pub = factor( V6199,
                                          labels = c("Seguran�a",
                                                     "Inseguran�a leve",
                                                     "Inseguran�a moderada",
                                                     "Inseguran�a grave")),
                       ebia_insan = car::recode( V6199 ,
                                                 " 1 ='Seguran�a' ;
                                               c(2,3,4)='Inseguran�a' " ))


############################################################
## Desenho amostral de domic�lios

POF_dom <- subset( desenho.pof , 
                   NUM_UC == 1) # S� para as UCs=1

# C�lculo das preval�ncias de (in)seguran�a alimentar nos domic�lios:

# C�lculo todas as categorias nos domic�lios:
prev_dom_g01 <- svymean( ~ factor(ebia_pub),
                         POF_dom, 
                         na.rm=T)

# C�lculo com as categorias da EBIA agregadas nos domic�lios:
prev_dom_g02 <- svymean( ~ factor(ebia_insan),
                         POF_dom, 
                         na.rm=T)

Tab3_c1 <- rbind(prev_dom_g01[1],
                 prev_dom_g02[1],
                 prev_dom_g01[2],
                 prev_dom_g01[3],
                 prev_dom_g01[4])

# C�lculo por situa��o do domic�lio com todas as categorias EBIA nos domic�lios:
prev_dom_g03 <- svyby( ~ factor(ebia_pub),
                       ~ factor(TIPO_SITUACAO_REG,
                                labels=c("Urbana",
                                         "Rural")),
                       POF_dom, 
                       svymean,
                       na.rm=T)

# C�lculo por situa��o do domic�lio com as categorias EBIA agregadas nos domic�lios:
prev_dom_g04 <- svyby( ~ factor(ebia_insan),
                       ~ factor(TIPO_SITUACAO_REG,
                                labels=c("Urbana",
                                         "Rural")),
                       POF_dom, 
                       svymean,
                       na.rm=T)

Tab3_c2_c3 <- rbind(prev_dom_g03[,2],
                    prev_dom_g04[,2],
                    prev_dom_g03[,3],
                    prev_dom_g03[,4],
                    prev_dom_g03[,5])

# Parte referente � POF e domic�lios particulares da tabela 3 da publica��o: Pesquisa de Or�amentos Familiares 2017-2018: An�lise da seguran�a alimentar no Brasil
EBIA_POF_dom <- data.frame(Total=round(Tab3_c1[,1]*100,1),
                           Urbana=round(Tab3_c2_c3[,1]*100,1),
                           Rural=round(Tab3_c2_c3[,2]*100,1),
                           row.names = c(" Com seguran�a alimentar",
                                         " Com inseguran�a alimentar",
                                         "Leve",
                                         "Moderada",
                                         "Grave"))

# Estimativas dos totais de domic�lios com todas as categorias EBIA nos domic�lios:
cont_tot_dom_g01 <- svyby( ~ one, 
                           ~ factor(ebia_pub,
                                    c("Seguran�a",
                                      "Inseguran�a leve",
                                      "Inseguran�a moderada",
                                      "Inseguran�a grave")),
                           POF_dom, 
                           svytotal,
                           na.rm=T)

# Estimativas dos totais de domic�lios com categorias EBIA agregadas nos domic�lios:
cont_tot_dom_g02 <- svyby( ~ one, 
                           ~ factor(ebia_insan,
                                    levels=c("Inseguran�a",
                                             "Seguran�a")),
                           POF_dom, 
                           svytotal,
                           na.rm=T)

Tab2_c1 <- rbind(cont_tot_dom_g01[1,2],
                 cont_tot_dom_g02[1,2],
                 cont_tot_dom_g01[2,2],
                 cont_tot_dom_g01[3,2],
                 cont_tot_dom_g01[4,2])

# Estimativas dos totais de domic�lios com todas as categorias EBIA nos domic�lios 
# por situa��o do domic�lio:
cont_tot_dom_g03 <- svyby( ~ one, 
                           ~ factor(ebia_pub,
                                    c("Seguran�a",
                                      "Inseguran�a leve",
                                      "Inseguran�a moderada",
                                      "Inseguran�a grave"))
                           + factor(TIPO_SITUACAO_REG,
                                    labels=c("Urbana",
                                             "Rural")),
                           POF_dom, 
                           svytotal,
                           na.rm=T)

# Estimativas dos totais de domic�lios com categorias EBIA agregadas nos domic�lios
# por situa��o do domic�lio:
cont_tot_dom_g04 <- svyby( ~ one, 
                           ~ factor(ebia_insan,
                                    c("Inseguran�a",
                                      "Seguran�a"))
                           + factor(TIPO_SITUACAO_REG,
                                    labels=c("Urbana",
                                             "Rural")),
                           POF_dom, 
                           svytotal,
                           na.rm=T)

Tab2_c2_c3 <- rbind(cont_tot_dom_g03[c(1,5),3],
                    cont_tot_dom_g04[c(1,3),3],
                    cont_tot_dom_g03[c(2,6),3],
                    cont_tot_dom_g03[c(3,7),3],
                    cont_tot_dom_g03[c(4,8),3])

# Parte referente � POF e domic�lios particulares da tabela 2 da publica��o: Pesquisa de Or�amentos Familiares 2017-2018: An�lise da seguran�a alimentar no Brasil
# Observa��o: alguns valores calculados abaixo divergem ligeiramente dos publicados
# decorrente de ajustes feitos na publica��o para consist�ncia de totais de linhas e colunas 
# como consequ�ncia do arredondamento de valores
cont_tot_dom_POF <- data.frame(Total=round(Tab2_c1[,1]/1000,0),
                               Urbana=round(Tab2_c2_c3[,1]/1000,0),
                               Rural=round(Tab2_c2_c3[,2]/1000,0),
                               row.names = c(" Com seguran�a alimentar",
                                             " Com inseguran�a alimentar",
                                             "Leve",
                                             "Moderada",
                                             "Grave"))

############################################################
## Desenho amostral de moradores

morador <- readRDS("MORADOR.rds")

##########################################################################

# Desenho para a estimativa dos moradores segundo situa��o de 
# seguran�a alimentar

morador_novo <- 
  merge( morador,
         POF_dom$variables[POF_dom$variables$NUM_UC == 1,], # equivalente � base de domic�lios
         by=c("COD_UPA",
              "NUM_DOM"))

rm(morador)

# Limpando as vari�veis que duplicaram no merge
morador_novo <- transform(morador_novo,
                          NUM_UC.y = NULL,
                          COD_INFORMANTE.y = NULL,
                          TIPO_SITUACAO_REG.y = NULL,
                          ESTRATO_POF.y = NULL,
                          UF.y = NULL,
                          PESO.y = NULL,
                          PESO_FINAL.y = NULL,
                          RENDA_TOTAL.y = NULL,
                          NUM_UC = NUM_UC.x,
                          COD_INFORMANTE = COD_INFORMANTE.x,
                          TIPO_SITUACAO_REG = TIPO_SITUACAO_REG.x,
                          ESTRATO_POF = ESTRATO_POF.x,
                          UF = UF.x,
                          PESO = PESO.x,
                          PESO_FINAL = PESO_FINAL.x,
                          RENDA_TOTAL = RENDA_TOTAL.x,
                          NUM_UC.x = NULL,
                          COD_INFORMANTE.x = NULL,
                          TIPO_SITUACAO_REG.x = NULL,
                          ESTRATO_POF.x = NULL,
                          UF.x = NULL,
                          PESO.x = NULL,
                          PESO_FINAL.x = NULL,
                          RENDA_TOTAL.x = NULL)

# Desenho b�sico por morador
POF.morador.desenho <- svydesign(id = ~COD_UPA ,
                                 strata = ~ESTRATO_POF ,
                                 data = morador_novo ,
                                 weights = ~PESO ,
                                 nest = TRUE	)
  
# Prepata��o dos totais de p�s-estratifica��o
tot_morador <- aggregate(PESO_FINAL~pos_estrato,
                         sum,
                         data=morador_novo)
colnames(tot_morador) <- c("pos_estrato","Freq")

# Desnho final p�s-estratificado:
POF_morad <- postStratify( design = POF.morador.desenho ,
                           ~ pos_estrato ,
                           tot_morador)
  
# Confer�ncia de total
POF_morad <- transform(POF_morad,
                       one = 1)
  
#svytotal(~one,
#         POF_morad)

rm(POF.morador.desenho)


######################################################################

# C�lculo das preval�ncias de (in)seguran�a alimentar dos moradores nos domic�lios:

# C�lculo todas as categorias dos moradores nos domic�lios:
prev_mor_g01 <- svymean( ~ factor(ebia_pub),
                         POF_morad, 
                         na.rm=T)

# C�lculo com as categorias da EBIA agregadas dos moradores nos domic�lios:
prev_mor_g02 <- svymean( ~ factor(ebia_insan),
                         POF_morad, 
                         na.rm=T)

Tab3_c4 <- rbind(prev_mor_g01[1],
                 prev_mor_g02[1],
                 prev_mor_g01[2],
                 prev_mor_g01[3],
                 prev_mor_g01[4])

# C�lculo por situa��o do domic�lio com todas as categorias EBIA dos moradores nos domic�lios:
prev_mor_g03 <- svyby( ~ factor(ebia_pub),
                       ~ factor(TIPO_SITUACAO_REG,
                                labels=c("Urbana",
                                         "Rural")),
                       POF_morad, 
                       svymean,
                       na.rm=T)

# C�lculo por situa��o do domic�lio com as categorias EBIA agregadas dos moradores nos domic�lios:
prev_mor_g04 <- svyby( ~ factor(ebia_insan),
                       ~ factor(TIPO_SITUACAO_REG,
                                labels=c("Urbana",
                                         "Rural")),
                       POF_morad, 
                       svymean,
                       na.rm=T)

Tab3_c5_c6 <- rbind(prev_mor_g03[,2],
                    prev_mor_g04[,2],
                    prev_mor_g03[,3],
                    prev_mor_g03[,4],
                    prev_mor_g03[,5])

# Parte referente � POF e moradores da tabela 3 da publica��o: Pesquisa de Or�amentos Familiares 2017-2018: An�lise da seguran�a alimentar no Brasil
EBIA_POF_morad <- data.frame(Total=round(Tab3_c4[,1]*100,1),
                             Urbana=round(Tab3_c5_c6[,1]*100,1),
                             Rural=round(Tab3_c5_c6[,2]*100,1),
                             row.names = c(" Com seguran�a alimentar",
                                           " Com inseguran�a alimentar",
                                           "Leve",
                                           "Moderada",
                                           "Grave"))

# Estimativas dos totais de moradores com todas as categorias EBIA dos moradores nos domic�lios:
cont_tot_mor_g01 <- svyby( ~ one, 
                           ~ factor(ebia_pub,
                                    c("Seguran�a",
                                      "Inseguran�a leve",
                                      "Inseguran�a moderada",
                                      "Inseguran�a grave")),
                           POF_morad, 
                           svytotal,
                           na.rm=T)

# Estimativas dos totais de moradores com categorias EBIA agregadas dos moradores nos domic�lios:
cont_tot_mor_g02 <- svyby( ~ one, 
                           ~ factor(ebia_insan,
                                    levels=c("Inseguran�a",
                                             "Seguran�a")),
                           POF_morad, 
                           svytotal,
                           na.rm=T)

Tab2_c4 <- rbind(cont_tot_mor_g01[1,2],
                 cont_tot_mor_g02[1,2],
                 cont_tot_mor_g01[2,2],
                 cont_tot_mor_g01[3,2],
                 cont_tot_mor_g01[4,2])

# Estimativas dos totais de moradores com todas as categorias EBIA dos moradores nos domic�lios 
# por situa��o do domic�lio:
cont_tot_mor_g03 <- svyby( ~ one, 
                           ~ factor(ebia_pub,
                                    c("Seguran�a",
                                      "Inseguran�a leve",
                                      "Inseguran�a moderada",
                                      "Inseguran�a grave"))
                           + factor(TIPO_SITUACAO_REG,
                                    labels=c("Urbana",
                                             "Rural")),
                           POF_morad, 
                           svytotal,
                           na.rm=T)

# Estimativas dos totais de moradores com categorias EBIA agregadas dos moradores nos domic�lios
# por situa��o do domic�lio:
cont_tot_mor_g04 <- svyby( ~ one, 
                           ~ factor(ebia_insan,
                                    c("Inseguran�a",
                                      "Seguran�a"))
                           + factor(TIPO_SITUACAO_REG,
                                    labels=c("Urbana",
                                             "Rural")),
                           POF_morad, 
                           svytotal,
                           na.rm=T)

Tab2_c5_c6 <- rbind(cont_tot_mor_g03[c(1,5),3],
                    cont_tot_mor_g04[c(1,3),3],
                    cont_tot_mor_g03[c(2,6),3],
                    cont_tot_mor_g03[c(3,7),3],
                    cont_tot_mor_g03[c(4,8),3])

# Parte referente � POF e moradores da tabela 2 da publica��o: Pesquisa de Or�amentos Familiares 2017-2018: An�lise da seguran�a alimentar no Brasil
# Observa��o: alguns valores calculados abaixo divergem ligeiramente dos publicados
# decorrente de ajustes feitos na publica��o para consist�ncia de totais de linhas e colunas 
# como consequ�ncia do arredondamento de valores
cont_tot_mor_POF <- data.frame(Total=round(Tab2_c4[,1]/1000,0),
                               Urbana=round(Tab2_c5_c6[,1]/1000,0),
                               Rural=round(Tab2_c5_c6[,2]/1000,0),
                               row.names = c(" Com seguran�a alimentar",
                                             " Com inseguran�a alimentar",
                                             "Leve",
                                             "Moderada",
                                             "Grave"))

message("Parte referente � POF e domic�lios particulares da tabela 2 da publica��o- \nPesquisa de Or�amentos Familiares 2017-2018: \nAn�lise da seguran�a alimentar no Brasil")
cont_tot_dom_POF
message("Parte referente � POF e moradores da tabela 2 da publica��o- \nPesquisa de Or�amentos Familiares 2017-2018: \nAn�lise da seguran�a alimentar no Brasil")
cont_tot_mor_POF
message("Parte referente � POF e domic�lios particulares da tabela 3 da publica��o- \nPesquisa de Or�amentos Familiares 2017-2018: \nAn�lise da seguran�a alimentar no Brasil")
EBIA_POF_dom
message("Parte referente � POF e moradores da tabela 3 da publica��o- \nPesquisa de Or�amentos Familiares 2017-2018: \nAn�lise da seguran�a alimentar no Brasil")
EBIA_POF_morad
