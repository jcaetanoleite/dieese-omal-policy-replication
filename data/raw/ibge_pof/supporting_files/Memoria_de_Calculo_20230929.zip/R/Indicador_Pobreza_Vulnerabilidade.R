#                            POF 2017-2018

#  PROGRAMA PARA GERA��O DAS VARI�VEIS PARA OS INDICADORES DE POBREZA E VULNERABILIDADE 

# � preciso executar antes o arquivo "Leitura dos Microdados - R.R"
# que se encontra no arquivo compactado "Programas_de_Leitura.zip"
  # Este passo � necess�rio para gerar os arquivos com a extens�o .rds
# EM FORMATO ESPEC�FICO DO r QUE correspondentes aos arquivos com 
# extens�o .txt dos microdados da POF

# "....." indica a pasta/diret�rio de trabalho no HD local separados por "/"
# onde se encontram os arquivos .txt descompactados do arquivo Dados_aaaammdd.zip
# Exemplo: setwd("c:/POF2018/Dados_aaaammdd/")

setwd(".....") # Caminho onde se encontram as bases de dados


# Leitura da base de dados para c�culo dos indicadores de qualidade de vida

morador_quali_vida <- readRDS("MORADOR_QUALI_VIDA.rds")


# Calculo do Ci (CONTAGEM PONDERADA) e Vi (FUN��O PERDA)

# c�lculo do CI (CONTAGEM PONDERADA)
  
morador_quali_vida <- transform( morador_quali_vida,
                                 CI = V201 * 1/72 + #Peso final do vetor 201
                                   V202 * 1/72 + #Peso final do vetor 202
                                   V217 * 1/144 + #Peso final do vetor 217
                                   V204 * 1/144 + #Peso final do vetor 204
                                   V205 * 1/72 + #Peso final do vetor 205
                                   V206 * 1/144 + #Peso final do vetor 206
                                   V207 * 1/144 + #Peso final do vetor 207
                                   V210 * 1/144 + #Peso final do vetor 210
                                   V211 * 1/144 + #Peso final do vetor 211
                                   V208 * 1/72 + #Peso final do vetor 208
                                   V209 * 1/72 + #Peso final do vetor 209
                                   V212 * 1/72 + #Peso final do vetor 212
                                   V214 * 1/72 + #Peso final do vetor 214
                                   V215 * 1/72 + #Peso final do vetor 215
                                   V216 * 1/72 + #Peso final do vetor 216
                                   
                                   V301 * 1/48 + #Peso final do vetor 301
                                   V302 * 1/48 + #Peso final do vetor 302
                                   V303 * 1/48 + #Peso final do vetor 303
                                   V304 * 1/48 + #Peso final do vetor 304
                                   V305 * 1/48 + #Peso final do vetor 305
                                   V306 * 1/48 + #Peso final do vetor 306
                                   V307 * 1/48 + #Peso final do vetor 307
                                   V308 * 1/48 + #Peso final do vetor 308
                                   
                                   V501 * 1/30 + #Peso final do vetor 501
                                   V502 * 1/30 + #Peso final do vetor 502
                                   V503 * 1/30 + #Peso final do vetor 503
                                   V504 * 1/60 + #Peso final do vetor 504
                                   V505 * 1/60 + #Peso final do vetor 505
                                   V506 * 1/30 + #Peso final do vetor 506
                                   
                                   V401 * 1/30 + #Peso final do vetor 401
                                   V402 * 1/30 + #Peso final do vetor 402
                                   V403 * 1/30 + #Peso final do vetor 403
                                   
                                   V701 * 1/90 + #Peso final do vetor 701
                                   V702 * 1/90 + #Peso final do vetor 702
                                   V703 * 1/90 + #Peso final do vetor 703
                                   V704 * 1/30 + #Peso final do vetor 704
                                   
                                   V601 * 1/24 + #Peso final do vetor 601
                                   V602 * 1/120 + #Peso final do vetor 602
                                   V603 * 1/120 + #Peso final do vetor 603
                                   V604 * 1/120 + #Peso final do vetor 604
                                   V605 * 1/240 + #Peso final do vetor 605
                                   V611 * 1/240 + #Peso final do vetor 611
                                   V606 * 1/120 + #Peso final do vetor 606
                                   V607 * 1/48 + #Peso final do vetor 607
                                   V608 * 1/48 + #Peso final do vetor 608
                                   V609 * 1/48 + #Peso final do vetor 609
                                   V610 * 1/48 + #Peso final do vetor 610
                                   
                                   V801 * 1/24 + #Peso final do vetor 801
                                   V802 * 1/24 + #Peso final do vetor 802
                                   
                                   V901 * 1/24 + #Peso final do vetor 901
                                   V902 * 1/24 #Peso final do vetor 902
                                   )


# C�lculo do VI (FUN��O PERDA)

morador_quali_vida <- transform( morador_quali_vida,
                                 VI = (exp(CI) - 1)/(exp(1) - 1)
                                 )

# Defini��o das linhas de vulnerabilidade e de pobreza

LINHA_VUL = 0.10554753583601 # LINHA DETERMINANTE DA VULNERABILIDADE
LINHA_POB = 0.23023721634819 # LINHA DETERMINANTE DA POBREZA


# C�lculo da vari�veis indicadoras e as de base de c�lculo 
# de vulnerabilidade e pobreza do morador

morador_quali_vida <- transform( morador_quali_vida,
                                 # DETERMINA SE MORADOR EST� CLASSIFICADO NA VULNERABILIDADE
                                 VUL = ifelse(VI>LINHA_VUL,
                                              1,
                                              0
                                              ),
                                 # DETERMINA SE MORADOR EST� CLASSIFICADO NA POBREZA
                                 POB = ifelse(VI>LINHA_POB,
                                              1,
                                              0
                                              ),
                                 # BASE DE C�LCULO DA MEDIDA DE VULNERABILIDADE
                                 CALCULO_VUL  = (VI - LINHA_VUL)/(1 - LINHA_VUL),
                                 # BASE DE C�LCULO DA MEDIDA DE POBREZA
                                 CALCULO_POB  = (VI - LINHA_POB)/(1 - LINHA_POB)
                                 )


# C�LCULO DAS MEDIDAS DE VULNERABILIDADE E DE POBREZA

morador_quali_vida <- transform( morador_quali_vida,
                                 MEDIDA_VUL = ifelse(VUL == 1,
                                                     CALCULO_VUL,
                                                     0),
                                 MEDIDA_POB = ifelse(POB == 1,
                                                     CALCULO_POB,
                                                     0)
                                 )


# Observa��o: as vari�veis foram criadas dentro da tabela (data frame) morador_quali_vida